# re-export functions from {tidysmd}

#' @aliases tidysmd
#' @importFrom tidysmd geom_love
#' @export
tidysmd::geom_love
#' @aliases tidysmd
#' @importFrom tidysmd love_plot
#' @export
tidysmd::love_plot
#' @aliases tidysmd
#' @importFrom tidysmd tidy_smd
#' @export
tidysmd::tidy_smd
#' @aliases tidysmd
#' @importFrom tidysmd bind_matches
#' @export
tidysmd::bind_matches
