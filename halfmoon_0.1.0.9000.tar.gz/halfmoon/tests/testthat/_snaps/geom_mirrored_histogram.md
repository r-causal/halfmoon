# geom_mirrored_histogram errors correctly

    Computation failed in `stat_mirror_count()`.
    Caused by error in `compute_group()`:
    ! No group detected.
    * Do you need to use `aes(group = ...)` with your grouping variable?

